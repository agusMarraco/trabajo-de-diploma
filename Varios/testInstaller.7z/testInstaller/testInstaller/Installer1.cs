﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
namespace testInstaller
{
    [RunInstaller(true)]
    public partial class Installer1 : System.Configuration.Install.Installer
    {
        public Installer1()
        {
            InitializeComponent();
        }

        public override void Commit(IDictionary savedState)
        {
           
            String path = this.Context.Parameters["path"];
            String user = this.Context.Parameters["user"];
            String pass = this.Context.Parameters["pass"];

            File.WriteAllText("C:\\Users\\Agustin\\Desktop\\prueba.txt", path + user + pass);
            base.Commit(savedState);
            
        }
        public override void Install(IDictionary stateSaver)
        {
            
            System.Diagnostics.Debugger.Launch();
            System.Diagnostics.Debugger.Break();
            String path = this.Context.Parameters["path"];
            String user = this.Context.Parameters["user"];
            String pass = this.Context.Parameters["pass"];

            File.WriteAllText("C:\\Users\\Agustin\\Desktop\\prueba2.txt", path + user + pass);
            base.Install(stateSaver);

        }
    }
}
